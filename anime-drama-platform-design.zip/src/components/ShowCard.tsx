import React from 'react';
import { Link } from 'react-router-dom';
import { Play, Star, Plus } from 'lucide-react';
import { motion } from 'framer-motion';

export interface Show {
  id: string;
  title: string;
  image: string;
  rating: number;
  year: number;
  type: 'Anime' | 'K-Drama' | 'C-Drama';
  episodes: number;
  tags?: string[];
  trending?: boolean;
}

interface ShowCardProps {
  show: Show;
  index?: number;
}

export const ShowCard: React.FC<ShowCardProps> = ({ show, index = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="relative group rounded-xl overflow-hidden cursor-pointer w-full h-full flex flex-col"
    >
      <Link to={`/show/${show.id}`} className="block relative w-full pt-[140%]">
        <img
          src={show.image}
          alt={show.title}
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 group-hover:blur-[2px]"
          loading="lazy"
        />
        {/* Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-900/40 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

        {/* Hover Content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-4 group-hover:translate-y-0">
          <button className="bg-neon-blue text-zinc-950 rounded-full p-3 shadow-[0_0_15px_rgba(56,189,248,0.6)] transform hover:scale-110 transition-transform mb-3">
            <Play fill="currentColor" className="w-6 h-6 ml-1" />
          </button>
          <div className="flex items-center gap-1 text-white font-bold bg-zinc-900/80 px-2 py-1 rounded-md backdrop-blur-sm">
            <Star fill="#eab308" className="w-4 h-4 text-yellow-500" />
            <span>{show.rating}</span>
          </div>
        </div>

        {/* Top badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {show.trending && (
            <span className="bg-neon-pink text-white text-[10px] font-bold px-2 py-1 rounded shadow-[0_0_8px_rgba(236,72,153,0.5)] uppercase tracking-wider">
              Trending
            </span>
          )}
          <span className="bg-zinc-900/80 backdrop-blur-md text-zinc-300 text-[10px] font-semibold px-2 py-1 rounded border border-zinc-700/50">
            {show.type}
          </span>
        </div>
      </Link>
      
      {/* Footer Info */}
      <div className="mt-3 flex-grow flex flex-col justify-between px-1">
        <div>
          <h3 className="text-sm font-semibold text-white line-clamp-1 group-hover:text-neon-blue transition-colors duration-300">
            {show.title}
          </h3>
          <div className="flex items-center text-xs text-zinc-500 mt-1 gap-2">
            <span>{show.year}</span>
            <span>•</span>
            <span>{show.episodes} EPS</span>
          </div>
        </div>
        
        {/* Tags */}
        {show.tags && (
          <div className="flex flex-wrap gap-1 mt-2">
            {show.tags.slice(0, 2).map((tag, i) => (
              <span key={i} className="text-[10px] px-1.5 py-0.5 bg-zinc-800 text-zinc-400 rounded-sm border border-zinc-700">
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
};

interface CarouselProps {
  title: string;
  shows: Show[];
  viewAllLink?: string;
}

export const ShowsCarousel: React.FC<CarouselProps> = ({ title, shows, viewAllLink }) => {
  return (
    <div className="py-6">
      <div className="flex items-end justify-between mb-4 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <h2 className="text-xl md:text-2xl font-bold text-white relative inline-block">
          {title}
          <div className="absolute -bottom-1 left-0 w-1/2 h-0.5 bg-gradient-to-r from-neon-blue to-transparent"></div>
        </h2>
        {viewAllLink && (
          <Link to={viewAllLink} className="text-sm text-neon-blue hover:text-white transition-colors duration-300 flex items-center gap-1 font-medium">
            View All
          </Link>
        )}
      </div>
      
      {/* Horizontal Scroll Area */}
      <div className="w-full overflow-x-auto no-scrollbar pb-6 pt-2">
        <div className="flex gap-4 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto" style={{ width: 'max-content' }}>
          {shows.map((show, idx) => (
            <div key={show.id} className="w-[140px] sm:w-[160px] md:w-[200px] flex-shrink-0">
              <ShowCard show={show} index={idx} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
