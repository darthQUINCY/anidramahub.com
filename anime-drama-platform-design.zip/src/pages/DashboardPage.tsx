import React, { useState } from 'react';
import { User, Settings, Heart, Clock, PlayCircle, Play, LogOut, Edit2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ShowsCarousel } from '../components/ShowCard';
import { trendingShows, topPicks } from '../data/mockData';

const DashboardPage = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'watchlist' | 'history' | 'settings'>('overview');

  const continueWatching = topPicks.slice(0, 3).map(show => ({
    ...show,
    progress: Math.floor(Math.random() * 100),
    episode: Math.floor(Math.random() * show.episodes) + 1
  }));

  const watchlist = trendingShows.slice(2, 6);

  return (
    <div className="min-h-screen bg-zinc-950 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
      
      <div className="flex flex-col md:flex-row gap-8">
        
        {/* Sidebar Profile */}
        <aside className="w-full md:w-64 lg:w-72 flex-shrink-0">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 shadow-xl sticky top-24">
            <div className="flex flex-col items-center mb-6 relative">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-neon-blue to-neon-pink p-1 shadow-[0_0_20px_rgba(56,189,248,0.4)]">
                <div className="w-full h-full bg-zinc-900 rounded-full flex items-center justify-center overflow-hidden border-2 border-black">
                  <User className="w-12 h-12 text-zinc-500" />
                </div>
              </div>
              <button className="absolute bottom-16 -right-2 bg-zinc-800 p-1.5 rounded-full border border-zinc-700 hover:text-neon-blue transition-colors">
                <Edit2 className="w-4 h-4" />
              </button>
              <h2 className="text-xl font-bold text-white mt-4 tracking-wide">OtakuMaster99</h2>
              <p className="text-sm text-zinc-400 font-medium">Premium Member</p>
              
              <div className="flex items-center gap-2 mt-4 text-xs font-semibold">
                <span className="bg-zinc-800 px-3 py-1 rounded-full text-neon-blue border border-neon-blue/30 shadow-[0_0_8px_rgba(56,189,248,0.2)]">Anime Fan</span>
                <span className="bg-zinc-800 px-3 py-1 rounded-full text-neon-pink border border-neon-pink/30 shadow-[0_0_8px_rgba(236,72,153,0.2)]">K-Drama Lover</span>
              </div>
            </div>

            <nav className="space-y-2 border-t border-zinc-800/50 pt-6">
              {[
                { id: 'overview', icon: <User className="w-5 h-5" />, label: 'Overview' },
                { id: 'watchlist', icon: <Heart className="w-5 h-5" />, label: 'My Watchlist', badge: watchlist.length },
                { id: 'history', icon: <Clock className="w-5 h-5" />, label: 'Watch History' },
                { id: 'settings', icon: <Settings className="w-5 h-5" />, label: 'Preferences' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-300 font-medium ${
                    activeTab === item.id 
                      ? 'bg-gradient-to-r from-neon-blue/20 to-transparent text-white border-l-2 border-neon-blue shadow-[inset_4px_0_0_rgba(56,189,248,1)]' 
                      : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-white border-l-2 border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {item.icon}
                    {item.label}
                  </div>
                  {item.badge && (
                    <span className="bg-zinc-800 text-xs px-2 py-0.5 rounded-full text-zinc-300">{item.badge}</span>
                  )}
                </button>
              ))}
            </nav>

            <div className="mt-8 border-t border-zinc-800/50 pt-6">
              <button className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-red-400 hover:bg-red-400/10 hover:text-red-300 transition-colors font-medium border border-transparent hover:border-red-400/20">
                <LogOut className="w-5 h-5" />
                Sign Out
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-grow">
          {activeTab === 'overview' && (
            <div className="space-y-10 animate-fade-in">
              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Total Watched', value: '1,248', unit: 'Episodes' },
                  { label: 'Watch Time', value: '342', unit: 'Hours' },
                  { label: 'Completed', value: '56', unit: 'Series' },
                  { label: 'Following', value: '12', unit: 'Ongoing' }
                ].map((stat, i) => (
                  <div key={i} className="bg-zinc-900/40 border border-zinc-800/50 p-4 rounded-xl flex flex-col items-center justify-center text-center group hover:border-neon-blue/50 transition-colors">
                    <span className="text-3xl font-bold text-white mb-1 group-hover:text-neon-blue transition-colors duration-300">{stat.value}</span>
                    <span className="text-zinc-500 text-xs uppercase tracking-wider font-semibold">{stat.label}</span>
                  </div>
                ))}
              </div>

              {/* Continue Watching */}
              <div className="bg-zinc-900/30 border border-zinc-800/50 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <PlayCircle className="w-6 h-6 text-neon-pink" />
                    Continue Watching
                  </h3>
                  <Link to="#" className="text-sm text-neon-blue hover:text-white transition-colors">View All</Link>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {continueWatching.map((show) => (
                    <Link key={show.id} to={`/watch/${show.id}/${show.episode}`} className="group block relative overflow-hidden rounded-xl bg-zinc-900 border border-zinc-800/80 hover:border-neon-blue/50 transition-all duration-300 shadow-lg hover:shadow-[0_0_15px_rgba(56,189,248,0.2)]">
                      <div className="aspect-video relative overflow-hidden">
                        <img src={show.image} alt={show.title} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="bg-neon-blue/90 text-white p-3 rounded-full backdrop-blur-sm transform group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(56,189,248,0.6)]">
                            <Play fill="currentColor" className="w-6 h-6 ml-0.5" />
                          </div>
                        </div>
                        {/* Progress Bar */}
                        <div className="absolute bottom-0 left-0 w-full h-1.5 bg-zinc-800">
                          <div 
                            className="h-full bg-gradient-to-r from-neon-blue to-neon-pink shadow-[0_0_8px_rgba(56,189,248,0.8)]" 
                            style={{ width: `${show.progress}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="p-4">
                        <h4 className="font-bold text-white truncate group-hover:text-neon-blue transition-colors">{show.title}</h4>
                        <p className="text-sm text-zinc-400 mt-1 flex items-center gap-2">
                           <span className="font-semibold text-zinc-300">Ep {show.episode}</span>
                           <span className="text-zinc-600">•</span>
                           <span>{show.progress}% Complete</span>
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Recommendation Strip */}
              <div className="bg-gradient-to-r from-zinc-900 to-zinc-950 border border-zinc-800/80 rounded-2xl p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-neon-blue/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
                <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Upgrade to Premium</h3>
                    <p className="text-zinc-400 text-sm max-w-md">Get ad-free streaming, 4K UHD quality, and early access to simulcasts. Support your favorite creators.</p>
                  </div>
                  <button className="bg-gradient-to-r from-neon-blue to-blue-600 text-white font-bold px-8 py-3 rounded-lg hover:scale-105 transition-transform shadow-[0_0_15px_rgba(56,189,248,0.4)] whitespace-nowrap border border-neon-blue/50">
                    Get Premium Now
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'watchlist' && (
            <div className="animate-fade-in">
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <Heart className="w-6 h-6 text-neon-pink" fill="currentColor" />
                My Watchlist
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
                {watchlist.map((show, idx) => (
                  <div key={show.id} className="relative group">
                    <ShowsCarousel shows={[show]} title="" />
                    <button className="absolute top-4 right-4 bg-black/60 p-2 rounded-full text-white hover:text-red-500 hover:bg-black/80 transition-all backdrop-blur-md border border-white/10 opacity-0 group-hover:opacity-100 z-20">
                       <Heart className="w-4 h-4" fill="currentColor" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Placeholder for other tabs */}
          {(activeTab === 'history' || activeTab === 'settings') && (
            <div className="flex flex-col items-center justify-center h-64 text-zinc-500 bg-zinc-900/20 border border-zinc-800/50 rounded-2xl">
              <Settings className="w-12 h-12 mb-4 opacity-50 animate-spin-slow" />
              <p className="text-lg font-medium">Content for {activeTab} coming soon.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default DashboardPage;