import React from 'react';
import { Play, Info, Flame, Trophy, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { ShowsCarousel } from '../components/ShowCard';
import { trendingShows, topPicks, genres } from '../data/mockData';
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <div className="relative w-full h-[70vh] sm:h-[80vh] md:h-[90vh]">
      {/* Background Image/Video Placeholder */}
      <div className="absolute inset-0 w-full h-full">
        <img
          src="https://images.unsplash.com/photo-1542204165-65bf26472b9b?w=1920&q=80"
          alt="Hero Background"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/50 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#09090b] via-[#09090b]/30 to-transparent"></div>
      </div>

      <div className="absolute inset-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-end pb-20 sm:pb-32 z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl"
        >
          <div className="flex items-center gap-2 mb-4">
            <span className="bg-neon-pink text-white text-xs font-bold px-3 py-1 rounded-sm uppercase tracking-widest shadow-[0_0_10px_rgba(236,72,153,0.5)]">
              Now Streaming
            </span>
            <span className="text-zinc-300 text-sm font-semibold tracking-wider">
              SEASON 2 PREMIERE
            </span>
          </div>
          
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-bold text-white mb-4 leading-tight text-shadow-neon-blue">
            Watch Trending<br />Anime & Dramas<br />in One Place
          </h1>
          
          <p className="text-lg text-zinc-300 mb-8 max-w-xl line-clamp-3">
            Dive into the most immersive stories from Japan, Korea, and China. Join millions of fans worldwide. Experience ad-free streaming in 4K UHD.
          </p>
          
          <div className="flex flex-wrap items-center gap-4">
            <Link to="/watch/k1/1" className="flex items-center justify-center gap-2 bg-white text-black px-6 py-3 rounded-md font-bold text-lg hover:bg-zinc-200 transition-colors shadow-[0_0_15px_rgba(255,255,255,0.3)]">
              <Play fill="currentColor" className="w-5 h-5" />
              Start Watching
            </Link>
            <button className="flex items-center justify-center gap-2 bg-zinc-800/80 backdrop-blur-md text-white border border-zinc-700 px-6 py-3 rounded-md font-bold text-lg hover:bg-zinc-700 transition-colors">
              <Info className="w-5 h-5" />
              Explore More
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default function HomePage() {
  return (
    <div className="min-h-screen pb-10">
      <Hero />
      
      <div className="relative z-20 -mt-10">
        {/* Trending Section */}
        <div className="relative">
          <div className="absolute left-4 top-6 z-10">
            <Flame className="w-8 h-8 text-neon-pink drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]" />
          </div>
          <ShowsCarousel title="     Trending Now" shows={trendingShows} viewAllLink="/explore/trending" />
        </div>

        {/* Top Picks / Recommendations */}
        <div className="relative mt-4 bg-gradient-to-b from-zinc-950 to-zinc-900/50 pt-4">
          <div className="absolute left-4 top-10 z-10">
            <Sparkles className="w-7 h-7 text-neon-blue drop-shadow-[0_0_8px_rgba(56,189,248,0.8)]" />
          </div>
          <ShowsCarousel title="     Because You Watched K-Dramas" shows={topPicks} />
        </div>

        {/* Genres Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-2xl font-bold text-white mb-6">Explore by Genre</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {genres.map((genre) => (
              <Link
                key={genre.name}
                to={`/explore/anime?genre=${genre.name}`}
                className="group relative overflow-hidden rounded-xl aspect-[3/2] flex items-center justify-center p-4 cursor-pointer"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${genre.color} opacity-80 group-hover:scale-110 transition-transform duration-500`}></div>
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300"></div>
                <div className="relative z-10 flex flex-col items-center gap-2">
                  <span className="text-3xl filter drop-shadow-lg">{genre.icon}</span>
                  <span className="text-white font-bold tracking-wider">{genre.name}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* CTA / Email Capture */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="relative rounded-2xl overflow-hidden glass-panel p-8 sm:p-12 text-center shadow-neon-blue">
            <div className="absolute inset-0 bg-gradient-to-r from-neon-blue/10 via-neon-pink/10 to-neon-blue/10"></div>
            <div className="relative z-10 max-w-2xl mx-auto">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Never Miss an Episode</h2>
              <p className="text-zinc-300 mb-8">
                Join our community of millions. Get exclusive alerts for new releases, early access to premium content, and personalized recommendations.
              </p>
              <form className="flex flex-col sm:flex-row gap-4 justify-center" onSubmit={(e) => e.preventDefault()}>
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="px-6 py-3 rounded-md bg-zinc-900 border border-zinc-700 text-white focus:outline-none focus:border-neon-blue focus:ring-1 focus:ring-neon-blue w-full sm:w-96"
                />
                <button type="submit" className="bg-gradient-to-r from-neon-blue to-blue-600 text-white font-bold px-8 py-3 rounded-md hover:scale-105 transition-transform shadow-[0_0_15px_rgba(56,189,248,0.4)] whitespace-nowrap">
                  Join Free
                </button>
              </form>
              <p className="text-zinc-500 text-xs mt-4">By joining, you agree to our Terms of Service and Privacy Policy.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
