import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Pause, Volume2, Maximize, Settings, Subtitles, SkipForward, List } from 'lucide-react';
import { trendingShows, topPicks } from '../data/mockData';

const VideoPlayerPage = () => {
  const { id, episode } = useParams<{ id: string; episode: string }>();
  const navigate = useNavigate();
  const [isPlaying, setIsPlaying] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);

  // Mock data fetching
  const show = trendingShows.find(s => s.id === id) || topPicks[0];
  const currentEp = parseInt(episode || '1');

  // Dummy episodes
  const episodes = Array.from({ length: show.episodes }, (_, i) => ({
    number: i + 1,
    title: `Episode ${i + 1}`,
  }));

  const handleNextEpisode = () => {
    if (currentEp < show.episodes) {
      navigate(`/watch/${id}/${currentEp + 1}`);
    }
  };

  return (
    <div className="flex h-screen w-full bg-black overflow-hidden relative font-sans">
      
      {/* Top Navigation Bar (Fades out when inactive ideally) */}
      <div className="absolute top-0 left-0 right-0 p-4 md:p-6 flex items-center justify-between z-50 bg-gradient-to-b from-black/80 to-transparent transition-opacity duration-300">
        <button 
          onClick={() => navigate(`/show/${id}`)}
          className="flex items-center gap-2 text-white/80 hover:text-white transition-colors group"
        >
          <div className="bg-black/50 p-2 rounded-full group-hover:bg-zinc-800 backdrop-blur-md transition-colors border border-white/10">
            <ArrowLeft className="w-5 h-5" />
          </div>
          <span className="font-semibold text-sm hidden sm:inline drop-shadow-md">Back to {show.title}</span>
        </button>
        
        <div className="flex items-center gap-4">
          <div className="bg-black/50 px-4 py-2 rounded-full backdrop-blur-md border border-white/10 flex items-center gap-2 text-sm text-white font-medium">
             <span>Ep {currentEp}</span>
             <span className="text-white/50">•</span>
             <span className="text-neon-blue">{show.title}</span>
          </div>
          <button 
            onClick={() => setShowSidebar(!showSidebar)}
            className="bg-black/50 p-2.5 rounded-full hover:bg-zinc-800 text-white transition-colors backdrop-blur-md border border-white/10 shadow-[0_0_10px_rgba(0,0,0,0.5)] md:hidden"
          >
            <List className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Video Area */}
      <div className={`flex-grow relative h-full transition-all duration-300 ${showSidebar ? 'md:mr-80' : ''}`}>
        
        {/* Placeholder for Video Element */}
        <div className="absolute inset-0 bg-zinc-950 flex flex-col items-center justify-center group">
          
          <div className="absolute inset-0">
             <img src={show.image} alt="Video Poster" className="w-full h-full object-cover opacity-30" />
             <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
          </div>

          {/* Central Play Button */}
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="relative z-10 w-20 h-20 md:w-24 md:h-24 bg-neon-blue/20 hover:bg-neon-blue/40 text-neon-blue rounded-full flex items-center justify-center backdrop-blur-md transition-all duration-300 transform hover:scale-110 shadow-[0_0_30px_rgba(56,189,248,0.3)] border border-neon-blue/30"
          >
            {isPlaying ? (
              <Pause fill="currentColor" className="w-10 h-10 md:w-12 md:h-12" />
            ) : (
              <Play fill="currentColor" className="w-10 h-10 md:w-12 md:h-12 ml-2" />
            )}
          </button>

          {/* Dummy Subtitles */}
          {isPlaying && (
            <div className="absolute bottom-24 md:bottom-28 w-full text-center px-4 z-10 pointer-events-none">
              <span className="text-white text-xl md:text-2xl font-semibold px-4 py-1 bg-black/50 rounded inline-block text-shadow-neon-blue">
                [Subtitles: "We must push forward, no matter the cost..."]
              </span>
            </div>
          )}

          {/* Controls Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 bg-gradient-to-t from-black via-black/80 to-transparent z-20 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-300">
            
            {/* Progress Bar */}
            <div className="w-full h-1 md:h-1.5 bg-zinc-800 rounded-full mb-4 cursor-pointer relative group/progress">
              <div className="absolute top-0 left-0 h-full bg-neon-blue w-1/3 rounded-full shadow-[0_0_10px_rgba(56,189,248,0.8)]"></div>
              {/* Hover scrubber */}
              <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-3 h-3 md:w-4 md:h-4 bg-white rounded-full scale-0 group-hover/progress:scale-100 transition-transform shadow-lg"></div>
            </div>

            <div className="flex items-center justify-between text-white">
              <div className="flex items-center gap-4 md:gap-6">
                <button onClick={() => setIsPlaying(!isPlaying)} className="hover:text-neon-blue transition-colors">
                  {isPlaying ? <Pause className="w-6 h-6" fill="currentColor" /> : <Play className="w-6 h-6" fill="currentColor" />}
                </button>
                <button onClick={handleNextEpisode} className="hover:text-neon-blue transition-colors group relative">
                  <SkipForward className="w-6 h-6" fill="currentColor" />
                  <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-zinc-800 text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap transition-opacity pointer-events-none">Next Episode</span>
                </button>
                <div className="flex items-center gap-2 group/volume relative">
                  <button className="hover:text-neon-blue transition-colors">
                    <Volume2 className="w-5 h-5 md:w-6 md:h-6" />
                  </button>
                  <div className="w-0 overflow-hidden group-hover/volume:w-20 transition-all duration-300 ease-in-out h-1.5 bg-zinc-700 rounded-full cursor-pointer">
                    <div className="h-full bg-white w-2/3 rounded-full"></div>
                  </div>
                </div>
                <div className="text-xs md:text-sm font-medium tracking-wide">
                  08:24 <span className="text-zinc-500 mx-1">/</span> 24:00
                </div>
              </div>

              <div className="flex items-center gap-4 md:gap-6">
                <button className="hover:text-neon-blue transition-colors relative group">
                  <Subtitles className="w-5 h-5 md:w-6 md:h-6" />
                  <span className="absolute -top-8 right-0 bg-black/80 px-2 py-1 text-[10px] rounded border border-zinc-800 opacity-0 group-hover:opacity-100 transition-opacity">EN / JP</span>
                </button>
                <button className="hover:text-neon-blue transition-colors">
                  <Settings className="w-5 h-5 md:w-6 md:h-6" />
                </button>
                <button onClick={() => setShowSidebar(!showSidebar)} className="hidden md:block hover:text-neon-blue transition-colors">
                  <List className={`w-5 h-5 md:w-6 md:h-6 ${showSidebar ? 'text-neon-blue' : ''}`} />
                </button>
                <button className="hover:text-neon-blue transition-colors">
                  <Maximize className="w-5 h-5 md:w-6 md:h-6" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Episodes Sidebar */}
      <div 
        className={`fixed md:absolute top-0 right-0 h-full w-80 bg-zinc-950/95 backdrop-blur-xl border-l border-zinc-800/50 flex flex-col z-40 transition-transform duration-300 ease-in-out ${
          showSidebar ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-4 md:p-6 border-b border-zinc-800/50 mt-16 md:mt-0">
          <h2 className="text-xl font-bold text-white mb-2 line-clamp-1">{show.title}</h2>
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-400">Season 1</span>
            <span className="text-zinc-500 bg-zinc-900 px-2 py-0.5 rounded text-xs border border-zinc-800">{show.episodes} Episodes</span>
          </div>
        </div>

        <div className="flex-grow overflow-y-auto no-scrollbar p-2">
          {episodes.map((ep) => {
            const isCurrent = ep.number === currentEp;
            return (
              <Link
                key={ep.number}
                to={`/watch/${id}/${ep.number}`}
                className={`flex items-center gap-4 p-3 rounded-xl mb-2 transition-all duration-300 group relative overflow-hidden ${
                  isCurrent 
                    ? 'bg-zinc-800/80 border border-zinc-700/50 shadow-lg' 
                    : 'hover:bg-zinc-900/80 border border-transparent hover:border-zinc-800'
                }`}
              >
                {/* Active Indicator Line */}
                {isCurrent && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-neon-blue shadow-[0_0_8px_rgba(56,189,248,0.8)] rounded-l-xl"></div>
                )}
                
                <div className="relative w-28 aspect-video rounded-md overflow-hidden flex-shrink-0 bg-zinc-900">
                  <img src={show.image} alt={ep.title} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" />
                  {isCurrent && (
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <span className="text-[10px] font-bold text-white bg-neon-blue/80 px-1.5 py-0.5 rounded backdrop-blur-sm">PLAYING</span>
                    </div>
                  )}
                  {!isCurrent && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play fill="currentColor" className="w-6 h-6 text-white ml-1 shadow-lg" />
                    </div>
                  )}
                </div>
                
                <div className="flex-grow min-w-0">
                  <h4 className={`font-semibold text-sm truncate transition-colors ${isCurrent ? 'text-neon-blue' : 'text-zinc-200 group-hover:text-white'}`}>
                    {ep.number}. {ep.title}
                  </h4>
                  <p className="text-xs text-zinc-500 mt-1">24m</p>
                </div>
              </Link>
            );
          })}
        </div>
      </div>

    </div>
  );
};

export default VideoPlayerPage;