import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Play, Star, Plus, Share2, ThumbsUp, Calendar, Clock, Film } from 'lucide-react';
import { ShowsCarousel, Show } from '../components/ShowCard';
import { trendingShows, topPicks } from '../data/mockData';

const ShowDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<'episodes' | 'cast' | 'details' | 'reviews'>('episodes');

  // In a real app, fetch based on ID
  const show: Show = trendingShows.find(s => s.id === id) || topPicks[0];
  const similarShows = topPicks.slice(0, 6);

  // Generate fake episodes
  const episodes = Array.from({ length: show.episodes }, (_, i) => ({
    number: i + 1,
    title: `Episode ${i + 1}: The Beginning of the End`,
    duration: '24m',
    image: `https://images.unsplash.com/photo-${1500000000000 + (i * 1000)}?w=300&q=80`, // Randomish image
    description: 'Our heroes face an unexpected challenge that threatens to unravel everything they have worked for.',
    releaseDate: '2 days ago'
  }));

  return (
    <div className="min-h-screen bg-zinc-950 pb-20">
      {/* Hero Banner */}
      <div className="relative h-[60vh] md:h-[70vh] w-full">
        <div className="absolute inset-0">
          <img 
            src={show.image} 
            alt={show.title} 
            className="w-full h-full object-cover opacity-40 blur-sm"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/60 to-transparent"></div>
        </div>

        <div className="absolute bottom-0 left-0 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 translate-y-10 md:translate-y-20 flex flex-col md:flex-row gap-8 items-end z-20">
          {/* Poster */}
          <div className="hidden md:block w-64 flex-shrink-0 rounded-xl overflow-hidden shadow-2xl shadow-zinc-900/50 border border-zinc-800">
            <img src={show.image} alt={show.title} className="w-full h-auto object-cover aspect-[2/3]" />
          </div>

          {/* Info */}
          <div className="flex-grow pb-4 md:pb-0 w-full">
            <div className="flex items-center gap-2 mb-3">
              <span className="bg-neon-blue/20 text-neon-blue text-xs font-bold px-2 py-1 rounded shadow-[0_0_8px_rgba(56,189,248,0.2)] uppercase">
                {show.type}
              </span>
              <span className="flex items-center gap-1 text-yellow-500 text-sm font-bold bg-zinc-900/80 px-2 py-1 rounded">
                <Star className="w-4 h-4" fill="currentColor" /> {show.rating}
              </span>
              <span className="text-zinc-400 text-sm font-medium border border-zinc-700 px-2 py-1 rounded bg-zinc-900/50">
                {show.year}
              </span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
              {show.title}
            </h1>

            <div className="flex flex-wrap items-center gap-4 text-sm text-zinc-300 mb-6">
              <span className="flex items-center gap-1"><Film className="w-4 h-4" /> {show.episodes} Episodes</span>
              <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> 24m / ep</span>
              <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> Fall 2026</span>
              <div className="flex gap-2 ml-2">
                {show.tags?.map((tag, i) => (
                  <span key={i} className="text-xs text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded-full">{tag}</span>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <Link 
                to={`/watch/${show.id}/1`}
                className="flex items-center gap-2 bg-gradient-to-r from-neon-blue to-blue-600 text-white px-8 py-3 rounded-md font-bold text-lg hover:scale-105 transition-transform shadow-[0_0_15px_rgba(56,189,248,0.4)]"
              >
                <Play fill="currentColor" className="w-5 h-5" />
                Watch Ep 1
              </Link>
              <button className="flex items-center gap-2 bg-zinc-800/80 backdrop-blur-md text-white border border-zinc-700 px-6 py-3 rounded-md font-semibold hover:bg-zinc-700 transition-colors">
                <Plus className="w-5 h-5" />
                Watchlist
              </button>
              <div className="flex items-center gap-2 ml-auto md:ml-4">
                <button className="p-3 bg-zinc-900 border border-zinc-800 rounded-full hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors">
                  <ThumbsUp className="w-5 h-5" />
                </button>
                <button className="p-3 bg-zinc-900 border border-zinc-800 rounded-full hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 md:mt-32">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* Left Column (Content Tabs) */}
          <div className="lg:col-span-2">
            {/* Tabs */}
            <div className="flex border-b border-zinc-800 mb-6 no-scrollbar overflow-x-auto">
              {['episodes', 'cast', 'details', 'reviews'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`px-6 py-3 font-semibold text-sm capitalize whitespace-nowrap transition-colors relative ${
                    activeTab === tab ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  {tab}
                  {activeTab === tab && (
                    <div className="absolute bottom-0 left-0 w-full h-0.5 bg-neon-blue shadow-[0_0_8px_rgba(56,189,248,0.8)]"></div>
                  )}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="min-h-[400px]">
              {activeTab === 'episodes' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-white">Episodes ({show.episodes})</h3>
                    <select className="bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:border-neon-blue">
                      <option>Season 1</option>
                    </select>
                  </div>
                  
                  {episodes.map((ep) => (
                    <Link 
                      key={ep.number} 
                      to={`/watch/${show.id}/${ep.number}`}
                      className="flex flex-col sm:flex-row gap-4 p-4 rounded-xl bg-zinc-900/50 border border-zinc-800/50 hover:bg-zinc-800 hover:border-zinc-700 transition-all duration-300 group"
                    >
                      <div className="relative w-full sm:w-48 aspect-video rounded-md overflow-hidden flex-shrink-0 bg-zinc-800">
                        {/* Fake image with fallback */}
                        <div className="absolute inset-0 bg-zinc-800 flex items-center justify-center text-zinc-600">
                           <Play className="w-8 h-8" />
                        </div>
                        <img src={show.image} alt={ep.title} className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500" />
                        
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="bg-white text-black p-2 rounded-full">
                            <Play fill="currentColor" className="w-4 h-4 ml-0.5" />
                          </div>
                        </div>
                        <span className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded font-medium">
                          {ep.duration}
                        </span>
                      </div>
                      
                      <div className="flex-grow flex flex-col justify-center">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-white font-semibold group-hover:text-neon-blue transition-colors">
                            {ep.number}. {ep.title.split(': ')[1]}
                          </h4>
                        </div>
                        <p className="text-zinc-400 text-sm line-clamp-2 mb-2">{ep.description}</p>
                        <span className="text-zinc-500 text-xs">{ep.releaseDate}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              )}

              {activeTab === 'details' && (
                <div className="text-zinc-300 space-y-6 bg-zinc-900/30 p-6 rounded-xl border border-zinc-800/50">
                  <p className="leading-relaxed">
                    Set in a world where danger lurks around every corner, {show.title} follows the harrowing journey of our protagonist. Combining breathtaking animation with a deeply emotional narrative, it explores themes of loss, resilience, and the bonds that tie us together.
                  </p>
                  <p className="leading-relaxed">
                    Produced by the legendary studios known for their high-quality visual output, this series has quickly become a fan favorite, trending globally upon release. 
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 pt-6 border-t border-zinc-800 mt-6 text-sm">
                    <div>
                      <span className="block text-zinc-500 mb-1">Director</span>
                      <span className="text-white font-medium">Tetsuya Nomura</span>
                    </div>
                    <div>
                      <span className="block text-zinc-500 mb-1">Studio</span>
                      <span className="text-white font-medium">Mappa / Ufotable</span>
                    </div>
                    <div>
                      <span className="block text-zinc-500 mb-1">Audio</span>
                      <span className="text-white font-medium">Japanese, English</span>
                    </div>
                    <div>
                      <span className="block text-zinc-500 mb-1">Subtitles</span>
                      <span className="text-white font-medium">Multiple Languages</span>
                    </div>
                    <div>
                      <span className="block text-zinc-500 mb-1">Age Rating</span>
                      <span className="text-white font-medium">TV-MA</span>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Dummy content for other tabs */}
              {(activeTab === 'cast' || activeTab === 'reviews') && (
                <div className="flex flex-col items-center justify-center py-20 text-zinc-500">
                  <Film className="w-12 h-12 mb-4 opacity-50" />
                  <p>Content for {activeTab} coming soon.</p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column (Sidebar) */}
          <div className="lg:col-span-1 space-y-8">
            {/* About Box */}
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 shadow-lg">
              <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
                <span className="w-1 h-5 bg-neon-blue rounded-full"></span> 
                Synopsis
              </h3>
              <p className="text-sm text-zinc-400 leading-relaxed mb-4">
                A masterpiece of {show.tags?.join(' and ')} that has captured the hearts of millions. Follow the incredible journey filled with stunning visuals, an unforgettable soundtrack, and plot twists that will leave you breathless.
              </p>
              <div className="space-y-3 pt-4 border-t border-zinc-800 text-sm">
                <div className="flex justify-between">
                  <span className="text-zinc-500">Status</span>
                  <span className="text-white font-medium">Finished Airing</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Aired</span>
                  <span className="text-white font-medium">Apr 2026 - Sep 2026</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Broadcast</span>
                  <span className="text-white font-medium">Sundays at 23:15 (JST)</span>
                </div>
              </div>
            </div>

            {/* Tags/Keywords */}
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 shadow-lg">
              <h3 className="text-white font-bold text-lg mb-4">Keywords</h3>
              <div className="flex flex-wrap gap-2">
                {show.tags?.concat(['Trending', 'HD', 'Must Watch', 'Masterpiece']).map((tag, i) => (
                  <span key={i} className="bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-300 text-xs px-3 py-1.5 rounded-full cursor-pointer transition-colors">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Similar Shows */}
        <div className="mt-16 pb-10 border-t border-zinc-900 pt-10">
          <ShowsCarousel title="     Similar to this" shows={similarShows} />
        </div>
      </div>
    </div>
  );
};

export default ShowDetailPage;