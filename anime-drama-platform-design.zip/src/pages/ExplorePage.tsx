import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { Filter, ChevronDown, Check } from 'lucide-react';
import { ShowCard, Show } from '../components/ShowCard';
import { trendingShows, topPicks } from '../data/mockData';

const ExplorePage = () => {
  const { category } = useParams<{ category: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const [shows, setShows] = useState<Show[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const genreParam = searchParams.get('genre');

  useEffect(() => {
    // Combine mock data and filter based on category and search params
    let combined = [...trendingShows, ...topPicks];
    
    if (category && category !== 'trending') {
      const typeMap: Record<string, string> = {
        'anime': 'Anime',
        'kdrama': 'K-Drama',
        'cdrama': 'C-Drama'
      };
      const filterType = typeMap[category.toLowerCase()];
      if (filterType) {
        combined = combined.filter(s => s.type === filterType);
      }
    }

    if (genreParam) {
      combined = combined.filter(s => s.tags?.includes(genreParam));
    }

    // Duplicate data to fill grid for demo purposes
    setShows([...combined, ...combined, ...combined, ...combined].map((s, i) => ({...s, id: `${s.id}-${i}`})));
  }, [category, genreParam]);

  const categories = ['All', 'Action', 'Romance', 'Fantasy', 'Sci-Fi', 'Thriller', 'Comedy'];
  const years = ['2026', '2025', '2024', '2023', 'Older'];
  const sorts = ['Trending', 'Latest', 'Most Watched', 'Highest Rated'];

  const handleFilterClick = (type: string, value: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (value === 'All') {
      newParams.delete(type);
    } else {
      newParams.set(type, value);
    }
    setSearchParams(newParams);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8 min-h-screen">
      
      {/* Mobile Filter Toggle */}
      <button 
        className="md:hidden flex items-center gap-2 bg-zinc-900 border border-zinc-700 px-4 py-2 rounded-md text-white font-medium sticky top-20 z-40 shadow-lg"
        onClick={() => setIsFilterOpen(!isFilterOpen)}
      >
        <Filter className="w-5 h-5" /> Filters
      </button>

      {/* Sidebar Filters */}
      <aside className={`w-full md:w-64 flex-shrink-0 space-y-8 sticky top-24 h-[calc(100vh-6rem)] overflow-y-auto pr-4 no-scrollbar pb-20 transition-transform duration-300 ${isFilterOpen ? 'block' : 'hidden md:block'}`}>
        <div>
          <h2 className="text-xl font-bold text-white mb-4 capitalize">Explore {category}</h2>
          <div className="space-y-6">
            
            {/* Sort */}
            <div>
              <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                Sort By <ChevronDown className="w-4 h-4" />
              </h3>
              <div className="space-y-2">
                {sorts.map(sort => (
                  <label key={sort} className="flex items-center gap-3 cursor-pointer group">
                    <input type="radio" name="sort" className="form-radio text-neon-blue bg-zinc-900 border-zinc-700 focus:ring-neon-blue" defaultChecked={sort === 'Trending'} />
                    <span className="text-zinc-300 group-hover:text-white transition-colors">{sort}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Genres */}
            <div>
              <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                Genres <ChevronDown className="w-4 h-4" />
              </h3>
              <div className="space-y-2">
                {categories.map(cat => {
                  const isActive = (genreParam === cat) || (cat === 'All' && !genreParam);
                  return (
                    <button 
                      key={cat} 
                      onClick={() => handleFilterClick('genre', cat)}
                      className="flex items-center gap-3 group w-full text-left"
                    >
                      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${isActive ? 'bg-neon-blue border-neon-blue' : 'bg-zinc-900 border-zinc-700 group-hover:border-neon-blue'}`}>
                        {isActive && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className={`transition-colors ${isActive ? 'text-white font-medium' : 'text-zinc-300 group-hover:text-white'}`}>{cat}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Year */}
            <div>
              <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                Release Year <ChevronDown className="w-4 h-4" />
              </h3>
              <div className="flex flex-wrap gap-2">
                {years.map(year => (
                  <button key={year} className="px-3 py-1 bg-zinc-900 border border-zinc-700 hover:border-neon-blue text-zinc-300 hover:text-white rounded-full text-sm transition-all duration-300">
                    {year}
                  </button>
                ))}
              </div>
            </div>

            {/* Status (For K/C Drama) */}
            {(category === 'kdrama' || category === 'cdrama') && (
              <div>
                <h3 className="text-sm font-semibold text-zinc-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  Status <ChevronDown className="w-4 h-4" />
                </h3>
                <div className="space-y-2">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <input type="checkbox" className="form-checkbox text-neon-blue bg-zinc-900 border-zinc-700 focus:ring-neon-blue rounded" />
                    <span className="text-zinc-300 group-hover:text-white transition-colors">Currently Airing</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <input type="checkbox" className="form-checkbox text-neon-blue bg-zinc-900 border-zinc-700 focus:ring-neon-blue rounded" />
                    <span className="text-zinc-300 group-hover:text-white transition-colors">Completed Series</span>
                  </label>
                </div>
              </div>
            )}

            <button className="w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-white font-semibold rounded-md border border-zinc-700 transition-colors">
              Apply Filters
            </button>
          </div>
        </div>
      </aside>

      {/* Main Grid */}
      <main className="flex-grow">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-white capitalize">
            {category === 'kdrama' ? 'K-Dramas' : category === 'cdrama' ? 'C-Dramas' : category || 'Trending'}
            <span className="text-sm text-zinc-500 font-normal ml-3">Showing {shows.length} results</span>
          </h1>
        </div>

        {shows.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
            {shows.map((show, idx) => (
              <ShowCard key={show.id} show={show} index={idx % 10} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-zinc-900/50 rounded-xl border border-zinc-800">
            <h2 className="text-xl text-zinc-300">No shows found matching your filters.</h2>
            <button 
              onClick={() => setSearchParams({})}
              className="mt-4 text-neon-blue hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}

        {shows.length > 0 && (
          <div className="mt-12 flex justify-center">
            <button className="bg-transparent border border-zinc-700 text-white hover:bg-zinc-800 hover:border-zinc-600 px-8 py-3 rounded-full font-medium transition-all duration-300">
              Load More
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default ExplorePage;