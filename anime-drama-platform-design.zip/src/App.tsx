import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Home, Search, Bell, User, Menu, X, PlayCircle, LogIn } from 'lucide-react';

// Pages
import HomePage from './pages/HomePage';
import ExplorePage from './pages/ExplorePage';
import ShowDetailPage from './pages/ShowDetailPage';
import VideoPlayerPage from './pages/VideoPlayerPage';
import DashboardPage from './pages/DashboardPage';

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const location = useLocation();
  const isPlayer = location.pathname.includes('/watch');

  if (isPlayer) return null; // Hide nav on video player

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Anime', path: '/explore/anime' },
    { name: 'K-Drama', path: '/explore/kdrama' },
    { name: 'C-Drama', path: '/explore/cdrama' },
    { name: 'Community', path: '/community' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-panel border-b-0">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <PlayCircle className="h-8 w-8 text-neon-blue drop-shadow-[0_0_8px_rgba(56,189,248,0.8)]" />
              <span className="text-xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink text-shadow-neon-blue">
                STREAMVERSE
              </span>
            </Link>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    className="text-zinc-300 hover:text-white hover:text-shadow-neon-blue px-3 py-2 rounded-md text-sm font-medium transition-all duration-300"
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-4">
            <button className="text-zinc-400 hover:text-white transition-colors">
              <Search className="h-5 w-5" />
            </button>
            <button className="text-zinc-400 hover:text-white transition-colors relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-0 right-0 h-2 w-2 bg-neon-pink rounded-full shadow-[0_0_8px_#ec4899]"></span>
            </button>
            <Link to="/dashboard" className="bg-zinc-800 hover:bg-zinc-700 p-2 rounded-full border border-zinc-700 transition-colors">
              <User className="h-5 w-5 text-zinc-300" />
            </Link>
          </div>

          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-zinc-400 hover:text-white inline-flex items-center justify-center p-2 rounded-md"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden glass-panel border-t border-zinc-800/50">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className="text-zinc-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium"
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/dashboard"
              onClick={() => setIsOpen(false)}
              className="text-zinc-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium flex items-center gap-2"
            >
              <User className="h-5 w-5" /> Profile
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

const Footer = () => {
  const location = useLocation();
  if (location.pathname.includes('/watch')) return null;

  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 py-12 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <PlayCircle className="h-6 w-6 text-neon-blue" />
              <span className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-pink">
                STREAMVERSE
              </span>
            </div>
            <p className="text-zinc-400 text-sm mb-4">
              Your ultimate destination for trending Anime, K-Dramas, and C-Dramas. Fast streaming, HD quality, global fan community.
            </p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Navigation</h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li><Link to="/explore/anime" className="hover:text-neon-blue transition-colors">Anime</Link></li>
              <li><Link to="/explore/kdrama" className="hover:text-neon-blue transition-colors">K-Drama</Link></li>
              <li><Link to="/explore/cdrama" className="hover:text-neon-blue transition-colors">C-Drama</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Support</h3>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li><a href="#" className="hover:text-neon-blue transition-colors">FAQ</a></li>
              <li><a href="#" className="hover:text-neon-blue transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-neon-blue transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-neon-blue transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Newsletter</h3>
            <p className="text-zinc-400 text-sm mb-2">Get latest episode alerts</p>
            <div className="flex">
              <input type="email" placeholder="Email address" className="bg-zinc-900 border border-zinc-800 rounded-l-md px-3 py-2 text-sm w-full focus:outline-none focus:border-neon-blue text-white" />
              <button className="bg-gradient-to-r from-neon-blue to-blue-600 px-4 py-2 rounded-r-md text-sm font-semibold text-white hover:opacity-90">
                Join
              </button>
            </div>
          </div>
        </div>
        <div className="border-t border-zinc-900 mt-12 pt-8 text-center text-sm text-zinc-500">
          © {new Date().getFullYear()} StreamVerse. All rights reserved. Built for fans.
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col relative bg-zinc-950">
        <Navbar />
        <main className="flex-grow pt-16">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/explore/:category" element={<ExplorePage />} />
            <Route path="/show/:id" element={<ShowDetailPage />} />
            <Route path="/watch/:id/:episode" element={<VideoPlayerPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="*" element={<div className="text-center py-20"><h1 className="text-4xl text-white">404 - Not Found</h1></div>} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}
